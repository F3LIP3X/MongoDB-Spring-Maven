package com.RafaFelipe.MongoDBSpringMaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoDbSpringMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongoDbSpringMavenApplication.class, args);
	}

}
