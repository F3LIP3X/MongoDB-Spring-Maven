package com.RafaFelipe.MongoDBSpringMaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoDbSpringMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
